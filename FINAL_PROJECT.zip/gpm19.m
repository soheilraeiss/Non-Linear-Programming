
f = @(x) x(1)^2 + x(2)^2;


gradf = @(x) [2 * x(1); 2 * x(2)];

proj_nonneg = @(x) max(x, 0);


lb = [0; 0];
ub = [1; 1];
proj_box = @(x) max(min(x, ub), lb);


r = 1;
proj_ball = @(x) x * min(1, r / norm(x));


x0 = [-2; -1];

max_iter = 100;


[x1, fval1, num_iter1] = gradient_projection(f, gradf, proj_nonneg, x0, max_iter);


[x2, fval2, num_iter2] = gradient_projection(f, gradf, proj_box, x0, max_iter);

[x3, fval3, num_iter3] = gradient_projection(f, gradf, proj_ball, x0, max_iter);

disp("Nonnegative Orthant:");
disp("Optimal Solution:"); disp(x1);
disp("Optimal Value:"); disp(fval1);
disp("Number of Iterations:"); disp(num_iter1);

disp("Box:");
disp("Optimal Solution:"); disp(x2);
disp("Optimal Value:"); disp(fval2);
disp("Number of Iterations:"); disp(num_iter2);

disp("Ball:");
disp("Optimal Solution:"); disp(x3);
disp("Optimal Value:"); disp(fval3);
disp("Number of Iterations:"); disp(num_iter3);


function [x, fval, num_iter] = gradient_projection(f, gradf, proj, x0, max_iter)
    alpha = 1;
    x = x0;
    for i = 1:max_iter
        g = gradf(x);
        x_new = proj(x - alpha * g);
        if norm(x - x_new) < 1e-5 
            break;
        end
        x = x_new;
    end
    fval = f(x);
    num_iter = i;
end
