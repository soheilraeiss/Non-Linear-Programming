
randn('seed', 314);

x = zeros(1000, 1);
x(1:250) = 1;
x(251:500) = 3;
x(501:750) = 0;
x(751:1000) = 2;


figure(1)
plot(1:1000, x, '.')
axis([0, 1000, -1, 4])
title('True Step Signal')
xlabel('x')
ylabel('y')


y = x + 0.05 * randn(size(x));

figure(2)
plot(1:1000, y, '.')
axis([0, 1000, -1, 4])
title('Noisy Step Signal')
xlabel('x')
ylabel('y')


lambda = 100; 
n = length(y); 


L=sparse(n-1,n);
for i=1:n-1
L(i,i)=1;
L(i,i+1)=-1;
end


mu = zeros(n-1, 1);


for i = 1:1000
    mu = mu - 0.25 * L * (L' * mu) + 0.5 * (L * y);
    mu = lambda * mu ./ max(abs(mu), lambda);
    xde = y - 0.5 * L' * mu;
end

figure(5)

plot(1:1000, x, '.', 'DisplayName', 'True Signal');
hold on
plot(1:1000, y, '.', 'DisplayName', 'Noisy Signal');
plot(1:250, xde(1:250), 'g', 'LineWidth', 1.5, 'DisplayName', 'Denoised Signal');
plot(251:500, xde(251:500), 'g', 'LineWidth', 1.5);
plot(501:750, xde(501:750), 'g', 'LineWidth', 1.5);
plot(751:1000, xde(751:1000), 'g', 'LineWidth', 1.5);
axis([0, 1000, -1, 4])
legend('Location', 'best');
title('Denoising using regularization with norm 1');
xlabel('Sample Index');
ylabel('Signal Value');
