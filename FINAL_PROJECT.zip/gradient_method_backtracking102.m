function iterations = gradient_method_backtracking102(A_values, x0, s, alpha, beta, epsilon)
iterations = zeros(size(A_values));

for i = 1:numel(A_values)
    A = [1, 0; 0, A_values(i)];
    f = @(x) x' * A * x;
    g = @(x) 2 * A * x;
    
    x = x0;
    grad = g(x);
    fun_val = f(x);
    iter = 0;
    
    while (norm(grad) > epsilon)
        iter = iter + 1;
        t = s;
        
        while (fun_val - f(x - t * grad) < alpha * t * norm(grad)^2)
            t = beta * t;
        end
        
        x = x - t * grad;
        fun_val = f(x);
        grad = g(x);
        fprintf('iter_number = %3d norm_grad = %2.6f fun_val = %2.6f \n', iter, norm(grad), fun_val);
    end
    
    iterations(i) = iter;
end


figure;
plot(A_values, iterations);
xlabel('A values');
ylabel('Number of Iterations');
title('Number of Iterations vs. Condition Number of A');

end


%for run the code : A_values = [0.01, 0.005, 0.002, 0.001];
%x0 = [0.01; 1];
%s = 2;
%alpha = 0.25;
%beta = 0.5;
%epsilon = 1e-5;
%iterations = gradient_method_backtracking102(A_values, x0, s, alpha, beta, epsilon)
%r
